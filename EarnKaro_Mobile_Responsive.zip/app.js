function spinWheel() {
  alert("Spinning the wheel...");
}
function withdraw() {
  alert("Initiating withdrawal...");
}
